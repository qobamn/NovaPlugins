package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanRole;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class ClanCommand implements CommandExecutor, TabCompleter {
    private final NovaClans plugin;
    private final ClanManager cm;
    private final MessageManager msg;

    public ClanCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.cm = plugin.getClanManager();
        this.msg = plugin.getMessageManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            msg.sendRaw(sender, "&c\u0422\u0435\u043a \u043e\u0439\u044b\u043d\u0448\u044b\u043b\u0430\u0440 \u043e\u0440\u044b\u043d\u0434\u0430\u0439 \u0430\u043b\u0430\u0434\u044b.");
            return true;
        }
        Player player = (Player) sender;
        if (args.length == 0) {
            plugin.getMenuManager().openMainMenu(player);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "help" -> handleHelp(player);
            case "create" -> handleCreate(player, args);
            case "delete" -> cm.deleteClan(player);
            case "invite" -> handleInvite(player, args);
            case "accept" -> cm.acceptInvite(player);
            case "deny" -> cm.denyInvite(player);
            case "kick" -> handleKick(player, args);
            case "promote" -> handlePromote(player, args);
            case "role" -> handleRole(player, args);
            case "chat" -> cm.toggleClanChat(player);
            case "storage" -> handleStorage(player, args);
            case "quest" -> plugin.getMenuManager().openQuestMenu(player);
            case "top" -> plugin.getMenuManager().openTopMenu(player);
            case "pvp" -> cm.togglePvp(player);
            case "leave" -> cm.leaveClan(player);
            default -> msg.send((CommandSender) player, "invalid-usage");
        }
        return true;
    }

    private void handleHelp(Player player) {
        msg.sendList((CommandSender) player, "clan-help");
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan create <\u0430\u0442>");
            return;
        }
        cm.createClan(player, args[1]);
    }

    private void handleInvite(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan invite <\u043e\u0439\u044b\u043d\u0448\u044b>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            msg.send((CommandSender) player, "player-not-found", "{player}", args[1]);
            return;
        }
        cm.invitePlayer(player, target);
    }

    private void handleKick(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan kick <\u043e\u0439\u044b\u043d\u0448\u044b>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            msg.send((CommandSender) player, "player-not-found", "{player}", args[1]);
            return;
        }
        cm.kickPlayer(player, target);
    }

    private void handlePromote(Player player, String[] args) {
        if (args.length < 2) {
            msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan promote <\u043e\u0439\u044b\u043d\u0448\u044b>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            msg.send((CommandSender) player, "player-not-found", "{player}", args[1]);
            return;
        }
        cm.promoteMember(player, target);
    }

    private void handleRole(Player player, String[] args) {
        if (args.length < 3) {
            msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan role <\u043e\u0439\u044b\u043d\u0448\u044b> <MEMBER|DEPUTY>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            msg.send((CommandSender) player, "player-not-found", "{player}", args[1]);
            return;
        }
        ClanRole role = ClanRole.fromString(args[2]);
        if (role == null) {
            msg.send((CommandSender) player, "clan-role-invalid");
            return;
        }
        cm.setRole(player, target, role);
    }

    private void handleStorage(Player player, String[] args) {
        if (args.length == 1) {
            plugin.getMenuManager().openStorageInfoMenu(player);
            return;
        }
        switch (args[1].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) {
                    msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan storage add <\u0441\u0443\u043c\u043c\u0430>");
                    return;
                }
                try {
                    cm.depositToStorage(player, Double.parseDouble(args[2]));
                } catch (NumberFormatException e) {
                    msg.send((CommandSender) player, "clan-storage-invalid-amount");
                }
            }
            case "take" -> {
                if (args.length < 3) {
                    msg.sendRaw((CommandSender) player, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/clan storage take <\u0441\u0443\u043c\u043c\u0430>");
                    return;
                }
                try {
                    cm.withdrawFromStorage(player, Double.parseDouble(args[2]));
                } catch (NumberFormatException e) {
                    msg.send((CommandSender) player, "clan-storage-invalid-amount");
                }
            }
            default -> plugin.getMenuManager().openStorageInfoMenu(player);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("create", "invite", "kick", "role", "promote", "delete", "chat", "storage", "quest", "top", "help", "accept", "deny", "pvp", "leave");
        }
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "invite", "kick", "promote", "role" -> Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
                case "storage" -> Arrays.asList("add", "take");
                default -> List.of();
            };
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("role")) {
            return Arrays.asList("MEMBER", "DEPUTY");
        }
        return List.of();
    }
}
