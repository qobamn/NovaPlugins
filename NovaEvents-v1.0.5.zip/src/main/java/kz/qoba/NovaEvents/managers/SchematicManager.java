package kz.qoba.NovaEvents.managers;

import org.bukkit.block.data.BlockData;
import java.util.logging.Level;
import org.bukkit.block.BlockState;
import java.util.List;
import java.util.Comparator;
import java.util.Collection;
import java.util.ArrayList;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.WorldEditException;
import org.bukkit.block.Block;
import kz.qoba.NovaEvents.models.ActiveEventData;
import com.sk89q.worldedit.regions.CuboidRegion;
import org.bukkit.World;
import org.bukkit.Location;
import java.util.Iterator;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import java.io.InputStream;
import java.io.FileInputStream;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import java.io.IOException;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import java.io.File;
import kz.qoba.NovaEvents.NovaEvents;

public class SchematicManager
{
    private final NovaEvents plugin;
    private final File schematicsFolder;
    
    public SchematicManager(final NovaEvents plugin) {
        this.plugin = plugin;
        this.schematicsFolder = new File(plugin.getDataFolder(), "schematics");
        if (!this.schematicsFolder.exists()) {
            this.schematicsFolder.mkdirs();
        }
    }
    
    public File getSchematicsFolder() {
        return this.schematicsFolder;
    }
    
    public File resolveSchematicFile(final String relativePath) {
        return new File(this.schematicsFolder, relativePath.replace("\\", "/"));
    }
    
    public boolean schematicExists(final String relativePath) {
        return this.resolveSchematicFile(relativePath).exists();
    }
    
    public Clipboard loadSchematic(final String relativePath) throws IOException {
        final File file = this.resolveSchematicFile(relativePath);
        if (!file.exists()) {
            throw new IOException("Schematic file not found: " + relativePath);
        }
        final ClipboardFormat format = ClipboardFormats.findByFile(file);
        if (format == null) {
            throw new IOException("Unknown schematic format: " + relativePath);
        }
        final ClipboardReader reader = format.getReader((InputStream)new FileInputStream(file));
        Clipboard var5;
        try {
            var5 = reader.read();
        }
        catch (final Throwable var6) {
            if (reader != null) {
                try {
                    reader.close();
                }
                catch (final Throwable var7) {
                    var6.addSuppressed(var7);
                }
            }
            throw var6;
        }
        if (reader != null) {
            reader.close();
        }
        return var5;
    }
    
    public SolidBounds computeSolidBounds(final Clipboard clipboard) {
        final BlockVector3 clipMin = clipboard.getRegion().getMinimumPoint();
        final BlockVector3 clipMax = clipboard.getRegion().getMaximumPoint();
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        boolean found = false;
        for (final BlockVector3 pt : clipboard.getRegion()) {
            if (!clipboard.getBlock(pt).getBlockType().getMaterial().isAir()) {
                found = true;
                minX = Math.min(minX, pt.x());
                minY = Math.min(minY, pt.y());
                minZ = Math.min(minZ, pt.z());
                maxX = Math.max(maxX, pt.x());
                maxY = Math.max(maxY, pt.y());
                maxZ = Math.max(maxZ, pt.z());
            }
        }
        if (!found) {
            final BlockVector3 center = clipboard.getRegion().getCenter().toBlockPoint();
            return new SolidBounds(clipMin, clipMax, center);
        }
        return new SolidBounds(BlockVector3.at(minX, minY, minZ), BlockVector3.at(maxX, maxY, maxZ), BlockVector3.at((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2));
    }
    
    public Placement calculatePlacement(final Clipboard clipboard, final Location anchor, final World world, final int extraYOffset) {
        final SolidBounds solid = this.computeSolidBounds(clipboard);
        final BlockVector3 clipMin = clipboard.getRegion().getMinimumPoint();
        final BlockVector3 clipMax = clipboard.getRegion().getMaximumPoint();
        final int surfaceY = world.getHighestBlockYAt(anchor.getBlockX(), anchor.getBlockZ()) + 1 + Math.max(0, extraYOffset);
        final int pasteX = anchor.getBlockX() - solid.getCenter().x() + clipMin.x();
        final int pasteY = surfaceY - solid.getSolidMin().y() + clipMin.y();
        final int pasteZ = anchor.getBlockZ() - solid.getCenter().z() + clipMin.z();
        final BlockVector3 pasteMin = BlockVector3.at(pasteX, pasteY, pasteZ);
        final BlockVector3 centerWorld = this.toWorld(pasteMin, clipMin, solid.getCenter());
        final BlockVector3 worldMax = this.toWorld(pasteMin, clipMin, clipMax);
        final CuboidRegion worldRegion = new CuboidRegion(pasteMin, worldMax);
        return new Placement(pasteMin, centerWorld, worldRegion);
    }
    
    public void prepareAndPaste(final Clipboard clipboard, final World world, final Placement placement, final ActiveEventData data) throws WorldEditException {
        data.clearPlacedBlockPositions();
        data.clearOriginalBlocks();
        final CuboidRegion region = placement.getWorldRegion();
        final BlockVector3 clipMin = clipboard.getRegion().getMinimumPoint();
        for (final BlockVector3 worldPt : region) {
            final String key = this.blockKey(worldPt);
            final Block block = world.getBlockAt(worldPt.x(), worldPt.y(), worldPt.z());
            data.saveOriginalBlock(key, block.getState());
            data.getPlacedBlockPositions().add(BlockVector3.at(worldPt.x(), worldPt.y(), worldPt.z()));
        }
        this.pasteSchematic(clipboard, world, placement.getPasteMin());
    }
    
    public void pasteSchematic(final Clipboard clipboard, final World world, final BlockVector3 pasteMin) throws WorldEditException {
        final com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(world);
        final EditSession editSession = WorldEdit.getInstance().newEditSession(weWorld);
        try {
            final ClipboardHolder holder = new ClipboardHolder(clipboard);
            final Operation operation = holder.createPaste((Extent)editSession).to(pasteMin).ignoreAirBlocks(false).build();
            Operations.complete(operation);
            editSession.flushSession();
        }
        catch (final Throwable var9) {
            if (editSession != null) {
                try {
                    editSession.close();
                }
                catch (final Throwable var10) {
                    var9.addSuppressed(var10);
                }
            }
            throw var9;
        }
        if (editSession != null) {
            editSession.close();
        }
    }
    
    public void cleanupSchematic(final World world, final ActiveEventData data) {
        if (world != null && data != null) {
            final List<BlockVector3> positions = new ArrayList<BlockVector3>(data.getPlacedBlockPositions());
            positions.sort(Comparator.comparingInt(BlockVector3::y).reversed());
            int restored = 0;
            for (final BlockVector3 pt : positions) {
                if (this.restoreBlockAt(world, data, pt)) {
                    ++restored;
                }
            }
            this.plugin.getLogger().info("Schematic cleanup: restored " + restored + " / " + positions.size() + " blocks");
            data.clearPlacedBlockPositions();
            data.clearOriginalBlocks();
        }
    }
    
    private BlockVector3 toWorld(final BlockVector3 pasteMin, final BlockVector3 clipMin, final BlockVector3 clipPoint) {
        return pasteMin.add(clipPoint.subtract(clipMin));
    }
    
    private boolean restoreBlockAt(final World world, final ActiveEventData data, final BlockVector3 pt) {
        final BlockState original = data.getOriginalBlocks().get(this.blockKey(pt));
        if (original == null) {
            return false;
        }
        try {
            final Block block = world.getBlockAt(pt.x(), pt.y(), pt.z());
            final BlockData target = original.getBlockData().clone();
            if (!block.getBlockData().matches(target)) {
                block.setBlockData(target, false);
            }
            return true;
        }
        catch (final Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Failed to restore block at " + this.blockKey(pt), (Throwable)e);
            return false;
        }
    }
    
    private String blockKey(final BlockVector3 pt) {
        final int var10000 = pt.x();
        return var10000 + ":" + pt.y() + ":" + pt.z();
    }
    
    public static final class Placement
    {
        private final BlockVector3 pasteMin;
        private final BlockVector3 centerWorld;
        private final CuboidRegion worldRegion;
        
        public Placement(final BlockVector3 pasteMin, final BlockVector3 centerWorld, final CuboidRegion worldRegion) {
            this.pasteMin = pasteMin;
            this.centerWorld = centerWorld;
            this.worldRegion = worldRegion;
        }
        
        public BlockVector3 getPasteMin() {
            return this.pasteMin;
        }
        
        public BlockVector3 getCenterWorld() {
            return this.centerWorld;
        }
        
        public CuboidRegion getWorldRegion() {
            return this.worldRegion;
        }
    }
    
    public static final class SolidBounds
    {
        private final BlockVector3 solidMin;
        private final BlockVector3 solidMax;
        private final BlockVector3 center;
        
        public SolidBounds(final BlockVector3 solidMin, final BlockVector3 solidMax, final BlockVector3 center) {
            this.solidMin = solidMin;
            this.solidMax = solidMax;
            this.center = center;
        }
        
        public BlockVector3 getSolidMin() {
            return this.solidMin;
        }
        
        public BlockVector3 getSolidMax() {
            return this.solidMax;
        }
        
        public BlockVector3 getCenter() {
            return this.center;
        }
    }
}
