package kz.qoba.NovaEvents.managers;

import java.util.Locale;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.managers.RegionManager;
import org.bukkit.World;
import java.util.logging.Level;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldedit.math.BlockVector3;
import org.bukkit.Location;
import kz.qoba.NovaEvents.NovaEvents;

public class WorldGuardRegionManager
{
    private final NovaEvents plugin;
    
    public WorldGuardRegionManager(final NovaEvents plugin) {
        this.plugin = plugin;
    }
    
    public String createEventRegion(final String eventId, final Location center, final int radius) {
        if (center == null || center.getWorld() == null) {
            return null;
        }
        final World world = center.getWorld();
        final RegionManager manager = this.getRegionManager(world);
        if (manager == null) {
            this.plugin.getLogger().warning("WorldGuard RegionManager not found for world: " + world.getName());
            return null;
        }
        final String regionId = this.buildRegionId(eventId, center);
        final int minY = Math.max(world.getMinHeight(), this.plugin.getConfigManager().getWorldGuardMinY());
        final int maxY = Math.min(world.getMaxHeight() - 1, this.plugin.getConfigManager().getWorldGuardMaxY());
        final BlockVector3 min = BlockVector3.at(center.getBlockX() - radius, minY, center.getBlockZ() - radius);
        final BlockVector3 max = BlockVector3.at(center.getBlockX() + radius, maxY, center.getBlockZ() + radius);
        final ProtectedRegion region = (ProtectedRegion)new ProtectedCuboidRegion(regionId, min, max);
        region.setFlag((Flag)Flags.PVP, (Object)StateFlag.State.ALLOW);
        region.setFlag((Flag)Flags.INTERACT, (Object)StateFlag.State.ALLOW);
        region.setFlag((Flag)Flags.USE, (Object)StateFlag.State.ALLOW);
        region.setFlag((Flag)Flags.CHEST_ACCESS, (Object)StateFlag.State.ALLOW);
        region.setFlag((Flag)Flags.BUILD, (Object)StateFlag.State.DENY);
        region.setFlag((Flag)Flags.BLOCK_BREAK, (Object)StateFlag.State.DENY);
        region.setFlag((Flag)Flags.BLOCK_PLACE, (Object)StateFlag.State.DENY);
        region.setFlag((Flag)Flags.CREEPER_EXPLOSION, (Object)StateFlag.State.DENY);
        region.setFlag((Flag)Flags.TNT, (Object)StateFlag.State.DENY);
        region.setPriority(this.plugin.getConfigManager().getConfig().getInt("worldguard.priority", 50));
        manager.addRegion(region);
        try {
            manager.save();
        }
        catch (final Exception e) {
            this.plugin.getLogger().log(Level.WARNING, "Could not save WorldGuard regions after creating " + regionId, (Throwable)e);
        }
        return regionId;
    }
    
    public void removeRegion(final World world, final String regionId) {
        if (world != null && regionId != null && !regionId.isBlank()) {
            final RegionManager manager = this.getRegionManager(world);
            if (manager != null) {
                manager.removeRegion(regionId);
                try {
                    manager.save();
                }
                catch (final Exception e) {
                    this.plugin.getLogger().log(Level.WARNING, "Could not save WorldGuard regions after removing " + regionId, (Throwable)e);
                }
            }
        }
    }
    
    private RegionManager getRegionManager(final World world) {
        final RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
        return container.get(BukkitAdapter.adapt(world));
    }
    
    private String buildRegionId(final String eventId, final Location center) {
        return ("alashevent_" + eventId + "_" + center.getBlockX() + "_" + center.getBlockZ()).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_\\-]", "_");
    }
}
