package kz.qoba.NovaEvents.managers;

import java.io.IOException;
import java.util.logging.Level;
import java.io.Serializable;
import kz.qoba.NovaEvents.models.EventParticleConfig;
import java.util.Comparator;
import org.bukkit.Material;
import kz.qoba.NovaEvents.models.EventStage;
import kz.qoba.NovaEvents.models.EventMenuItem;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BarColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import java.util.ArrayList;
import kz.qoba.NovaEvents.utils.BossBarUtil;
import java.util.LinkedHashMap;
import kz.qoba.NovaEvents.models.EventModel;
import java.util.List;
import java.util.Iterator;
import java.util.Map;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import org.bukkit.configuration.file.FileConfiguration;
import kz.qoba.NovaEvents.NovaEvents;

public class ConfigManager
{
    private final NovaEvents plugin;
    private FileConfiguration config;
    private FileConfiguration eventsConfig;
    private File eventsFile;
    
    public ConfigManager(final NovaEvents plugin) {
        this.plugin = plugin;
        this.reload();
    }
    
    public void reload() {
        this.plugin.reloadConfig();
        this.config = this.plugin.getConfig();
        this.eventsFile = new File(this.plugin.getDataFolder(), "events.yml");
        if (!this.eventsFile.exists()) {
            this.plugin.saveResource("events.yml", false);
        }
        this.eventsConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(this.eventsFile);
    }
    
    public String getMessage(final String key) {
        final String prefix = this.config.getString("prefix", "&#FBFFBA\u1d00 &7»&r &f");
        final String msg = this.config.getString("messages." + key, "&cMessage not found: " + key);
        return ColorUtil.colorize(prefix + msg);
    }
    
    public String getMessage(final String key, final Map<String, String> placeholders) {
        String msg = this.getMessage(key);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            msg = msg.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return msg;
    }
    
    public String getPrefix() {
        return ColorUtil.colorize(this.config.getString("prefix", "&#FBFFBA\u1d00 &7»&r &f"));
    }
    
    public String getSpawnWorld() {
        return this.config.getString("spawn-world", "world");
    }
    
    public int getSpawnInterval() {
        return this.config.getInt("spawn-interval", 20);
    }
    
    public int getBossbarDuration() {
        return this.config.getInt("bossbar-duration", 300);
    }
    
    public int getCleanupDelay() {
        return this.config.getInt("cleanup-delay", 240);
    }
    
    public int getSpawnRadius() {
        return this.config.getInt("spawn-radius", 500);
    }
    
    public int getSpawnMinRadius() {
        return this.config.getInt("spawn-min-radius", 50);
    }
    
    public int getSpawnAttempts() {
        return this.config.getInt("spawn-attempts", 80);
    }
    
    public int getSchematicPasteYOffset() {
        return Math.max(0, this.config.getInt("schematic-paste-y-offset", 3));
    }
    
    public int getWorldGuardRegionRadius() {
        return Math.max(1, this.config.getInt("worldguard.region-radius", 100));
    }
    
    public int getWorldGuardMinY() {
        return this.config.getInt("worldguard.min-y", -64);
    }
    
    public int getWorldGuardMaxY() {
        return this.config.getInt("worldguard.max-y", 320);
    }
    
    public List<String> getForbiddenSpawnBiomes() {
        return this.config.getStringList("spawn-forbidden-biomes");
    }
    
    public List<Integer> getGuiEventSlots() {
        return this.parseSlotList(this.config.getList("gui.event-slots"));
    }
    
    public FileConfiguration getConfig() {
        return this.config;
    }
    
    public FileConfiguration getEventsConfig() {
        return this.eventsConfig;
    }
    
    public Map<String, EventModel> loadEvents() {
        final Map<String, EventModel> events = new LinkedHashMap<String, EventModel>();
        final ConfigurationSection section = this.eventsConfig.getConfigurationSection("events");
        if (section == null) {
            return events;
        }
        final List<Integer> defaultSlots = this.getGuiEventSlots();
        int slotIndex = 0;
        for (final String id : section.getKeys(false)) {
            final ConfigurationSection es = section.getConfigurationSection(id);
            if (es != null) {
                final String name = es.getString("name", id);
                final String world = es.getString("world", this.getSpawnWorld());
                final boolean enabled = es.getBoolean("enabled", true);
                final int interval = es.getInt("spawn-interval", this.getSpawnInterval());
                final int durationSeconds = es.getInt("duration-seconds", this.getBossbarDuration());
                final int maxLootItems = es.getInt("max-loot-items", 12);
                final int lootEditorSize = this.normalizeInventorySize(es.getInt("loot-editor-size", 54));
                final int particleRadius = Math.max(1, es.getInt("particle-radius", 4));
                final int pasteYOffset = Math.max(0, es.getInt("paste-y-offset", this.getSchematicPasteYOffset()));
                final BarColor bossBarColor = BossBarUtil.parseColor(es.getString("bossbar-color", "YELLOW"));
                final BarStyle bossBarStyle = BossBarUtil.parseStyle(es.getString("bossbar-style", "SOLID"));
                final int defaultSlot = (slotIndex < defaultSlots.size()) ? defaultSlots.get(slotIndex) : 22;
                final EventMenuItem menuItem = this.loadMenuItem(es.getConfigurationSection("menu-item"), defaultSlot);
                ++slotIndex;
                final List<EventStage> stages = this.loadStages(id, es);
                final EventModel model = new EventModel(id, name, world, enabled, interval, durationSeconds, maxLootItems, lootEditorSize, particleRadius, pasteYOffset, bossBarColor, bossBarStyle, menuItem, stages);
                model.setParticles(this.loadParticles(es.getList("particles")));
                final List<?> lootList = es.getList("loot");
                if (lootList != null) {
                    final List<ItemStack> lootItems = new ArrayList<ItemStack>();
                    for (final Object obj : lootList) {
                        if (obj instanceof final ItemStack itemStack) {
                            lootItems.add(itemStack);
                        }
                    }
                    model.setLoot(lootItems);
                }
                model.setNextSpawnTime(System.currentTimeMillis() + interval * 60L * 1000L);
                events.put(id, model);
            }
        }
        return events;
    }
    
    private EventMenuItem loadMenuItem(final ConfigurationSection section, final int defaultSlot) {
        return (section == null) ? new EventMenuItem(Material.BLAZE_POWDER, "&e{event_name}", List.of("&7\u041a\u0435\u043b\u0435\u0441\u0456 \u0441\u043f\u0430\u0432\u043d: &f{next_spawn}", "&7\u041a\u04af\u0439: &f{status}", "&7\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u0442\u0430\u0440\u044b: &e{x}, {z}"), defaultSlot) : EventMenuItem.fromSection(section, defaultSlot);
    }
    
    private List<EventStage> loadStages(final String eventId, final ConfigurationSection eventSection) {
        final List<EventStage> stages = new ArrayList<EventStage>();
        final ConfigurationSection stagesSection = eventSection.getConfigurationSection("stages");
        if (stagesSection != null) {
            for (String stageKey : stagesSection.getKeys(false)) {
                final ConfigurationSection stageSection = stagesSection.getConfigurationSection(stageKey);
                if (stageSection != null) {
                    final String folder = stageSection.getString("folder", eventId + "/" + stageKey);
                    final String schematic = stageSection.getString("schematic", stageKey + ".schem");
                    boolean useSchematic = !EventStage.isSchematicDisabled(schematic);
                    if (stageSection.contains("use-schematic")) {
                        useSchematic = (stageSection.getBoolean("use-schematic") && useSchematic);
                    }
                    if (!useSchematic && !EventStage.isSchematicDisabled(schematic)) {
                        this.plugin.getLogger().warning("Stage " + eventId + "/" + stageKey + " has use-schematic: false but schematic is set to '" + schematic + "'. Set use-schematic: true or schematic: none");
                    }
                    final int duration = stageSection.getInt("duration-seconds", eventSection.getInt("duration-seconds", this.getBossbarDuration()));
                    final int offsetX = stageSection.getInt("shulker-offset.x", 0);
                    final int offsetY = stageSection.getInt("shulker-offset.y", 0);
                    final int offsetZ = stageSection.getInt("shulker-offset.z", 0);
                    final List<EventParticleConfig> stageParticles = this.loadParticles(stageSection.getList("particles"));
                    stages.add(new EventStage(folder, schematic, useSchematic, duration, offsetX, offsetY, offsetZ, stageParticles));
                }
            }
        }
        stages.sort(Comparator.comparingInt(stage -> this.extractTrailingNumber(stage.getFolder())));
        return stages;
    }
    
    private List<EventParticleConfig> loadParticles(final List<?> rawList) {
        final List<EventParticleConfig> particles = new ArrayList<EventParticleConfig>();
        if (rawList == null) {
            return particles;
        }
        for (final Object entry : rawList) {
            if (entry instanceof final ConfigurationSection section) {
                particles.add(EventParticleConfig.fromSection(section));
            }
            else {
                if (!(entry instanceof Map)) {
                    continue;
                }
                final Map<?, ?> map = (Map<?, ?>)entry;
                final YamlConfiguration temp = new YamlConfiguration();
                for (final Map.Entry<?, ?> mapEntry : map.entrySet()) {
                    if (mapEntry.getKey() != null) {
                        temp.set(String.valueOf(mapEntry.getKey()), (Object)mapEntry.getValue());
                    }
                }
                particles.add(EventParticleConfig.fromSection((ConfigurationSection)temp));
            }
        }
        return particles;
    }
    
    private void saveParticles(final String path, final List<EventParticleConfig> particles) {
        if (particles != null && !particles.isEmpty()) {
            final List<Map<String, Object>> serialized = new ArrayList<Map<String, Object>>();
            for (final EventParticleConfig particle : particles) {
                final Map<String, Object> map = new LinkedHashMap<String, Object>();
                map.put("type", particle.getTypeName());
                map.put("count", particle.getCount());
                map.put("speed", particle.getSpeed());
                map.put("spread", particle.getSpread());
                map.put("interval-ticks", particle.getIntervalTicks());
                map.put("offset-y", particle.getOffsetY());
                map.put("enabled", particle.isEnabled());
                if (particle.getDustColor() != null && !particle.getDustColor().isBlank()) {
                    map.put("dust-color", particle.getDustColor());
                    map.put("dust-size", particle.getDustSize());
                }
                serialized.add(map);
            }
            this.eventsConfig.set(path, (Object)serialized);
        }
        else {
            this.eventsConfig.set(path, (Object)null);
        }
    }
    
    private void saveMenuItem(final String path, final EventMenuItem menuItem) {
        if (menuItem != null) {
            this.eventsConfig.set(path + ".material", (Object)menuItem.getMaterial().name());
            this.eventsConfig.set(path + ".name", (Object)menuItem.getName());
            this.eventsConfig.set(path + ".lore", (Object)menuItem.getLore());
            this.eventsConfig.set(path + ".slot", (Object)menuItem.getSlot());
        }
    }
    
    private int extractTrailingNumber(final String text) {
        if (text == null) {
            return Integer.MAX_VALUE;
        }
        final String digits = text.replaceAll(".*?(\\d+)$", "$1");
        if (digits.matches("\\d+")) {
            try {
                return Integer.parseInt(digits);
            }
            catch (final NumberFormatException ex) {}
        }
        return Integer.MAX_VALUE;
    }
    
    public int normalizeInventorySize(final int size) {
        if (size < 9) {
            return 9;
        }
        if (size > 54) {
            return 54;
        }
        final int rows = (int)Math.ceil(size / 9.0);
        return rows * 9;
    }
    
    private List<Integer> parseSlotList(final List<?> raw) {
        final List<Integer> slots = new ArrayList<Integer>();
        if (raw == null) {
            slots.add(22);
            return slots;
        }
        for (final Object o : raw) {
            if (o instanceof final Number number) {
                slots.add(number.intValue());
            }
        }
        if (slots.isEmpty()) {
            slots.add(22);
        }
        return slots;
    }
    
    public void saveEvent(final EventModel model) {
        final String path = "events." + model.getId();
        this.eventsConfig.set(path + ".name", (Object)model.getDisplayName());
        this.eventsConfig.set(path + ".world", (Object)model.getWorld());
        this.eventsConfig.set(path + ".enabled", (Object)model.isEnabled());
        this.eventsConfig.set(path + ".spawn-interval", (Object)model.getSpawnInterval());
        this.eventsConfig.set(path + ".duration-seconds", (Object)model.getDurationSeconds());
        this.eventsConfig.set(path + ".max-loot-items", (Object)model.getMaxLootItems());
        this.eventsConfig.set(path + ".loot-editor-size", (Object)model.getLootEditorSize());
        this.eventsConfig.set(path + ".particle-radius", (Object)model.getParticleRadius());
        this.eventsConfig.set(path + ".paste-y-offset", (Object)model.getPasteYOffset());
        this.eventsConfig.set(path + ".bossbar-color", (Object)model.getBossBarColor().name());
        this.eventsConfig.set(path + ".bossbar-style", (Object)model.getBossBarStyle().name());
        this.eventsConfig.set(path + ".schematic", (Object)null);
        this.saveParticles(path + ".particles", model.getParticles());
        this.saveMenuItem(path + ".menu-item", model.getMenuItem());
        this.eventsConfig.set(path + ".stages", (Object)null);
        for (int i = 0; i < model.getStages().size(); ++i) {
            final EventStage stage = model.getStages().get(i);
            final String stagePath = path + ".stages.stage" + (i + 1);
            this.eventsConfig.set(stagePath + ".folder", (Object)stage.getFolder());
            if (stage.usesSchematic()) {
                this.eventsConfig.set(stagePath + ".schematic", (Object)stage.getSchematicFile());
                this.eventsConfig.set(stagePath + ".use-schematic", (Object)true);
            }
            else {
                this.eventsConfig.set(stagePath + ".schematic", (Object)"none");
                this.eventsConfig.set(stagePath + ".use-schematic", (Object)false);
            }
            this.eventsConfig.set(stagePath + ".duration-seconds", (Object)stage.getDurationSeconds());
            this.eventsConfig.set(stagePath + ".shulker-offset.x", (Object)stage.getShulkerOffsetX());
            this.eventsConfig.set(stagePath + ".shulker-offset.y", (Object)stage.getShulkerOffsetY());
            this.eventsConfig.set(stagePath + ".shulker-offset.z", (Object)stage.getShulkerOffsetZ());
            this.saveParticles(stagePath + ".particles", stage.getParticles());
        }
        this.eventsConfig.set(path + ".loot", (Object)model.getLoot());
        this.saveEventsConfig();
    }
    
    public void saveEventLoot(final EventModel model) {
        this.eventsConfig.set("events." + model.getId() + ".loot", (Object)model.getLoot());
        this.saveEventsConfig();
    }
    
    public void deleteEvent(final String id) {
        this.eventsConfig.set("events." + id, (Object)null);
        this.saveEventsConfig();
    }
    
    public void createEvent(final String id) {
        final String path = "events." + id;
        final List<Integer> slots = this.getGuiEventSlots();
        final int slot = slots.isEmpty() ? 22 : slots.get(Math.min(slots.size() - 1, 0));
        this.eventsConfig.set(path + ".name", "&f\u0418\u0432\u0435\u043d\u0442 " + id);
        this.eventsConfig.set(path + ".world", (Object)this.getSpawnWorld());
        this.eventsConfig.set(path + ".enabled", (Object)true);
        this.eventsConfig.set(path + ".spawn-interval", (Object)this.getSpawnInterval());
        this.eventsConfig.set(path + ".duration-seconds", (Object)120);
        this.eventsConfig.set(path + ".max-loot-items", (Object)12);
        this.eventsConfig.set(path + ".loot-editor-size", (Object)54);
        this.eventsConfig.set(path + ".particle-radius", (Object)4);
        this.eventsConfig.set(path + ".bossbar-color", (Object)"YELLOW");
        this.eventsConfig.set(path + ".bossbar-style", (Object)"SOLID");
        this.eventsConfig.set(path + ".menu-item.material", (Object)"BLAZE_POWDER");
        this.eventsConfig.set(path + ".menu-item.name", (Object)"&e{event_name}");
        this.eventsConfig.set(path + ".menu-item.lore", (Object)List.of("&7\u041a\u0435\u043b\u0435\u0441\u0456 \u0441\u043f\u0430\u0432\u043d: &f{next_spawn}", "&7\u041a\u04af\u0439: &f{status}", "&7\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u0442\u0430\u0440\u044b: &e{x}, {z}"));
        this.eventsConfig.set(path + ".menu-item.slot", (Object)slot);
        this.eventsConfig.set(path + ".loot", (Object)new ArrayList());
        this.eventsConfig.set(path + ".particles", (Object)List.of(Map.of("type", "PORTAL", "count", 6, "speed", 0.04, "spread", 2.0, "interval-ticks", 10, "enabled", true), Map.of("type", "END_ROD", "count", 3, "speed", 0.02, "spread", 1.5, "interval-ticks", 8, "enabled", true)));
        final String stagePath = path + ".stages.stage1";
        this.eventsConfig.set(stagePath + ".folder", id + "/stage1");
        this.eventsConfig.set(stagePath + ".schematic", (Object)"stage1.schem");
        this.eventsConfig.set(stagePath + ".use-schematic", (Object)true);
        this.eventsConfig.set(stagePath + ".duration-seconds", (Object)120);
        this.eventsConfig.set(stagePath + ".shulker-offset.x", (Object)0);
        this.eventsConfig.set(stagePath + ".shulker-offset.y", (Object)0);
        this.eventsConfig.set(stagePath + ".shulker-offset.z", (Object)0);
        this.saveEventsConfig();
    }
    
    private void saveEventsConfig() {
        try {
            this.eventsConfig.save(this.eventsFile);
        }
        catch (final IOException e) {
            this.plugin.getLogger().log(Level.SEVERE, "Could not save events.yml", e);
        }
    }
}
