package kz.qoba.NovaEvents.commands;

import org.bukkit.plugin.RegisteredListener;
import org.bukkit.event.Listener;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.ChatColor;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.HandlerList;
import kz.qoba.NovaEvents.listeners.PlayerListener;
import java.util.Iterator;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.entity.Player;
import java.util.Map;
import kz.qoba.NovaEvents.models.EventModel;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import kz.qoba.NovaEvents.NovaEvents;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.CommandExecutor;

public class AEventsCommand implements CommandExecutor, TabCompleter
{
    private final NovaEvents plugin;
    
    public AEventsCommand(final NovaEvents plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command command, final String label, final String[] args) {
        if (!sender.hasPermission("NovaEvents.admin")) {
            sender.sendMessage(this.plugin.getConfigManager().getMessage("no-permission"));
            return true;
        }
        if (args.length == 0) {
            this.sendHelp(sender);
            return true;
        }
        final String lowerCase = args[0].toLowerCase();
        switch (lowerCase) {
            case "reload": {
                this.plugin.getConfigManager().reload();
                this.plugin.getEventManager().loadEvents();
                this.plugin.getEventManager().startScheduler();
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-reloaded"));
                break;
            }
            case "list": {
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-list-header"));
                for (final EventModel model : this.plugin.getEventManager().getEvents().values()) {
                    final String status = model.getState().name();
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-list-entry", Map.of("event_id", model.getId(), "status", status)));
                }
                break;
            }
            case "forcestart": {
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-forcestart"));
                    return true;
                }
                final String id = args[1];
                final EventModel model = this.findEvent(args[1]);
                if (model == null) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                    return true;
                }
                if (model.getState() != EventModel.EventState.IDLE) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-already-active"));
                    return true;
                }
                this.plugin.getEventManager().spawnEvent(model);
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-started", Map.of("event_id", model.getId())));
                break;
            }
            case "tp": {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(ColorUtil.colorize("&c\u0422\u0435\u043a \u043e\u0439\u044b\u043d\u0448\u044b\u043b\u0430\u0440 \u04af\u0448\u0456\u043d!"));
                    return true;
                }
                final Player player = (Player)sender;
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-tp"));
                    return true;
                }
                final String id2 = args[1];
                final EventModel model2 = this.findEvent(args[1]);
                if (model2 == null) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id2)));
                    return true;
                }
                if (!this.plugin.getEventManager().teleportToEvent(player, model2)) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-active"));
                    return true;
                }
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-teleported", Map.of("event_id", model2.getId(), "event_name", ColorUtil.colorize(model2.getDisplayName()), "x", String.valueOf(model2.getActiveData().getSpawnLocation().getBlockX()), "z", String.valueOf(model2.getActiveData().getSpawnLocation().getBlockZ()))));
                break;
            }
            case "forcestop": {
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-forcestop"));
                    return true;
                }
                final String id = args[1];
                final EventModel model = this.findEvent(args[1]);
                if (model == null) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                    return true;
                }
                if (model.getState() == EventModel.EventState.IDLE) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-active"));
                    return true;
                }
                this.plugin.getEventManager().forceStop(model);
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-stopped", Map.of("event_id", model.getId())));
                break;
            }
            case "loot": {
                if (!(sender instanceof Player)) {
                    sender.sendMessage(ColorUtil.colorize("&c\u0422\u0435\u043a \u043e\u0439\u044b\u043d\u0448\u044b\u043b\u0430\u0440 \u04af\u0448\u0456\u043d!"));
                    return true;
                }
                final Player player = (Player)sender;
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-loot"));
                    return true;
                }
                final String id2 = args[1];
                final EventModel model2 = this.findEvent(args[1]);
                if (model2 == null) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id2)));
                    return true;
                }
                final PlayerListener listener = this.getPlayerListener();
                if (listener != null) {
                    listener.openLootGUI(player, model2);
                    break;
                }
                break;
            }
            case "create": {
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-create"));
                    return true;
                }
                final String id = args[1];
                if (this.plugin.getEventManager().getEvent(id) != null) {
                    sender.sendMessage(ColorUtil.colorize("&c\u0418\u0432\u0435\u043d\u0442 \u0431\u04b1\u0440\u044b\u043d\u043d\u0430\u043d \u0431\u0430\u0440: &e" + id));
                    return true;
                }
                this.plugin.getConfigManager().createEvent(id);
                this.plugin.getEventManager().loadEvents();
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-created", Map.of("event_id", id)));
                break;
            }
            case "delete": {
                if (args.length < 2) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-delete"));
                    return true;
                }
                final String id = args[1];
                final EventModel model = this.findEvent(args[1]);
                if (model == null) {
                    sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                    return true;
                }
                if (model.getState() != EventModel.EventState.IDLE) {
                    this.plugin.getEventManager().forceStop(model);
                }
                this.plugin.getConfigManager().deleteEvent(model.getId());
                this.plugin.getEventManager().loadEvents();
                sender.sendMessage(this.plugin.getConfigManager().getMessage("event-deleted", Map.of("event_id", model.getId())));
                break;
            }
            default: {
                this.sendHelp(sender);
                break;
            }
        }
        return true;
    }
    
    private void sendHelp(final CommandSender sender) {
        final String prefix = this.plugin.getConfigManager().getPrefix();
        sender.sendMessage(ColorUtil.colorize("&8&m-----&r " + prefix + "&aNovaEvents &8&m-----"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents forcestart <id> &7- \u0418\u0432\u0435\u043d\u0442\u0442\u0456 \u0456\u0441\u043a\u0435 \u049b\u043e\u0441\u0443"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents forcestop <id> &7- \u0418\u0432\u0435\u043d\u0442\u0442\u0456 \u0442\u043e\u049b\u0442\u0430\u0442\u0443"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents tp <id> &7- \u0411\u0435\u043b\u0441\u0435\u043d\u0434\u0456 \u0438\u0432\u0435\u043d\u0442\u043a\u0435 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents list &7- \u0418\u0432\u0435\u043d\u0442\u0442\u0435\u0440 \u0442\u0456\u0437\u0456\u043c\u0456"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents loot <id> &7- \u041b\u0443\u0442 \u0440\u0435\u0434\u0430\u043a\u0442\u043e\u0440\u044b"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents create <id> &7- \u0418\u0432\u0435\u043d\u0442 \u0436\u0430\u0441\u0430\u0443"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents delete <id> &7- \u0418\u0432\u0435\u043d\u0442\u0442\u0456 \u0436\u043e\u044e"));
        sender.sendMessage(ColorUtil.colorize("&e/aevents reload &7- \u049a\u0430\u0439\u0442\u0430 \u0436\u04af\u043a\u0442\u0435\u0443"));
        sender.sendMessage(ColorUtil.colorize("&8&m---------------------------------"));
    }
    
    private PlayerListener getPlayerListener() {
        return (PlayerListener)HandlerList.getRegisteredListeners((Plugin)this.plugin).stream().map(reg -> reg.getListener()).filter(l -> l instanceof PlayerListener).findFirst().orElse(null);
    }
    
    private EventModel findEvent(final String input) {
        final EventModel direct = this.plugin.getEventManager().getEvent(input);
        if (direct != null) {
            return direct;
        }
        final String normalized = ChatColor.stripColor(ColorUtil.colorize(input)).replace(" ", "").toLowerCase(Locale.ROOT);
        for (final EventModel model : this.plugin.getEventManager().getEvents().values()) {
            final String display = ChatColor.stripColor(ColorUtil.colorize(model.getDisplayName())).replace(" ", "").toLowerCase(Locale.ROOT);
            if (display.equals(normalized)) {
                return model;
            }
        }
        return null;
    }
    
    public List<String> onTabComplete(final CommandSender sender, final Command command, final String alias, final String[] args) {
        if (!sender.hasPermission("NovaEvents.admin")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            final List<String> cmds = List.of("forcestart", "forcestop", "tp", "list", "loot", "create", "delete", "reload");
            return cmds.stream().filter(c -> c.startsWith(args[0].toLowerCase())).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
        }
        if (args.length == 2) {
            final String sub = args[0].toLowerCase();
            if (sub.equals("forcestart") || sub.equals("forcestop") || sub.equals("tp") || sub.equals("loot") || sub.equals("delete")) {
                return this.plugin.getEventManager().getEvents().keySet().stream().filter(id -> id.startsWith(args[1])).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
            }
        }
        return Collections.emptyList();
    }
}
