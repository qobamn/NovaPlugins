package kz.qoba.NovaEvents.utils;

import org.bukkit.inventory.ItemFlag;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;

public class ItemBuilder
{
    private final ItemStack item;
    private final ItemMeta meta;

    // BUG FIX #1: AIR немесе метасыз материалда getItemMeta() null қайтарады.
    // Конструктор материал AIR немесе метасыз болса NullPointerException лақтырады.
    // Fix: материалды тексеріп, AIR болса IllegalArgumentException лақтыру.
    public ItemBuilder(final Material material) {
        if (material == null || material == Material.AIR) {
            throw new IllegalArgumentException("ItemBuilder material cannot be null or AIR");
        }
        this.item = new ItemStack(material);
        final ItemMeta fetchedMeta = this.item.getItemMeta();
        if (fetchedMeta == null) {
            throw new IllegalStateException("Material '" + material.name() + "' does not support ItemMeta");
        }
        this.meta = fetchedMeta;
    }

    public ItemBuilder name(final String name) {
        this.meta.setDisplayName(ColorUtil.colorize(name));
        return this;
    }

    public ItemBuilder lore(final String... lines) {
        this.meta.setLore((List)Arrays.stream(lines).map((Function<? super String, ?>)ColorUtil::colorize).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return this;
    }

    public ItemBuilder lore(final List<String> lines) {
        this.meta.setLore((List)lines.stream().map((Function<? super Object, ?>)ColorUtil::colorize).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        return this;
    }

    public ItemBuilder flags(final ItemFlag... flags) {
        this.meta.addItemFlags(flags);
        return this;
    }

    public ItemBuilder amount(final int amount) {
        // BUG FIX #2: setAmount() 0 немесе теріс санмен шақырылса ItemStack бұзылады.
        // Fix: amount 1-ден кем болса 1-ге клиптеу.
        this.item.setAmount(Math.max(1, amount));
        return this;
    }

    public ItemStack build() {
        this.item.setItemMeta(this.meta);
        return this.item;
    }
}
