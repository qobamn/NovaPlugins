package kz.qoba.NovaEvents.utils;

import org.bukkit.Location;
import kz.qoba.NovaEvents.models.ActiveEventData;
import java.util.Iterator;
import kz.qoba.NovaEvents.managers.EventManager;
import kz.qoba.NovaEvents.models.EventModel;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import kz.qoba.NovaEvents.NovaEvents;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;

public class NovaEventsExpansion extends PlaceholderExpansion
{
    private final NovaEvents plugin;
    
    public NovaEventsExpansion(final NovaEvents plugin) {
        this.plugin = plugin;
    }
    
    @NotNull
    public String getIdentifier() {
        return "nova_events";
    }
    
    @NotNull
    public String getAuthor() {
        return "QobaMn";
    }
    
    @NotNull
    public String getVersion() {
        return this.plugin.getDescription().getVersion();
    }
    
    public boolean persist() {
        return true;
    }
    
    public String onPlaceholderRequest(final Player player, @NotNull final String params) {
        final EventManager em = this.plugin.getEventManager();
        if (params.startsWith("coordinate_")) {
            final String eventId = params.substring("coordinate_".length());
            final EventModel model = em.getEvent(eventId);
            return this.resolveCoordinate(model);
        }
        if (params.startsWith("start_time_")) {
            final String eventId = params.substring("start_time_".length());
            final EventModel model = em.getEvent(eventId);
            return this.resolveStartTime(em, model);
        }
        if (params.equals("coordinate")) {
            for (final EventModel model : em.getEvents().values()) {
                if (model.getState() != EventModel.EventState.IDLE) {
                    return this.resolveCoordinate(model);
                }
            }
            return "\u0411\u0435\u043b\u0441\u0435\u043d\u0434\u0456 \u0438\u0432\u0435\u043d\u0442 \u0436\u043e\u049b";
        }
        if (!params.equals("start_time")) {
            return null;
        }
        final Iterator<EventModel> iterator2 = em.getEvents().values().iterator();
        while (iterator2.hasNext()) {
            final EventModel model = iterator2.next();
            if (model.getState() != EventModel.EventState.IDLE) {
                return this.resolveStartTime(em, model);
            }
        }
        EventModel nearest = null;
        long minDiff = Long.MAX_VALUE;
        final long now = System.currentTimeMillis();
        for (final EventModel model2 : em.getEvents().values()) {
            if (model2.isEnabled()) {
                final long diff = model2.getNextSpawnTime() - now;
                if (diff >= minDiff) {
                    continue;
                }
                minDiff = diff;
                nearest = model2;
            }
        }
        if (nearest == null) {
            return "\u0416\u043e\u049b";
        }
        return (minDiff <= 0L) ? "\u0416\u0430\u049b\u044b\u043d \u0430\u0440\u0430\u0434\u0430..." : EventManager.formatTime((int)(minDiff / 1000L));
    }
    
    private String resolveCoordinate(final EventModel model) {
        if (model == null) {
            return "\u0416\u043e\u049b";
        }
        final ActiveEventData data = model.getActiveData();
        if (data == null || model.getState() == EventModel.EventState.IDLE) {
            return "\u0411\u0435\u043b\u0441\u0435\u043d\u0434\u0456 \u0435\u043c\u0435\u0441";
        }
        final Location loc = data.getSpawnLocation();
        return loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ();
    }
    
    private String resolveStartTime(final EventManager em, final EventModel model) {
        if (model == null) {
            return "\u0416\u043e\u049b";
        }
        return em.getTimeUntilNextSpawn(model);
    }
}
