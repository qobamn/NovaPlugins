package kz.qoba.NovaEvents.models;

import org.bukkit.block.Block;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.HashMap;
import org.bukkit.inventory.Inventory;
import java.util.List;
import org.bukkit.block.BlockState;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import java.util.UUID;
import java.util.Map;
import org.bukkit.boss.BossBar;
import org.bukkit.Location;

public class ActiveEventData
{
    private final Location spawnLocation;
    private Location shulkerLocation;
    private final int protectedRadius;
    private final BossBar bossBar;
    private final long spawnTime;
    private long bossDuration;
    private boolean shulkerUnlocked;
    private boolean shulkerOpened;
    private final Map<UUID, Boolean> playerHasLooted;
    private CuboidRegion savedRegion;
    private CuboidRegion particleRegion;
    private BlockVector3 schematicOrigin;
    private BlockVector3 schematicCenterWorld;
    private boolean schematicPlaced;
    private String worldGuardRegionId;
    private final Map<String, BlockState> originalBlocks;
    private final List<BlockVector3> placedBlockPositions;
    private int currentStageIndex;
    private int currentStageSecondsLeft;
    private int bossBarTaskId;
    private int cleanupTaskId;
    private int lootPopulateTaskId;
    private int particleTaskId;
    private boolean lootPopulating;
    private boolean lootGenerated;
    private Inventory lootInventory;
    private List<UUID> hologramIds;
    private int hologramTaskId;
    
    public ActiveEventData(final Location spawnLocation, final BossBar bossBar, final long bossDuration, final int protectedRadius) {
        this.shulkerUnlocked = false;
        this.shulkerOpened = false;
        this.playerHasLooted = new HashMap<UUID, Boolean>();
        this.originalBlocks = new LinkedHashMap<String, BlockState>();
        this.placedBlockPositions = new ArrayList<BlockVector3>();
        this.currentStageIndex = 0;
        this.currentStageSecondsLeft = 0;
        this.bossBarTaskId = -1;
        this.cleanupTaskId = -1;
        this.lootPopulateTaskId = -1;
        this.particleTaskId = -1;
        this.lootPopulating = false;
        this.lootGenerated = false;
        this.hologramIds = new ArrayList<UUID>();
        this.hologramTaskId = -1;
        this.spawnLocation = spawnLocation;
        this.bossBar = bossBar;
        this.spawnTime = System.currentTimeMillis();
        this.bossDuration = bossDuration;
        this.protectedRadius = protectedRadius;
    }
    
    public Location getSpawnLocation() {
        return this.spawnLocation;
    }
    
    public Location getShulkerLocation() {
        return this.shulkerLocation;
    }
    
    public void setShulkerLocation(final Location shulkerLocation) {
        this.shulkerLocation = shulkerLocation;
    }
    
    public int getProtectedRadius() {
        return this.protectedRadius;
    }
    
    public boolean isInProtectedRadius(final Location location) {
        final Location center = (this.shulkerLocation != null) ? this.shulkerLocation : this.spawnLocation;
        if (location == null || center == null) {
            return false;
        }
        if (location.getWorld() == null || center.getWorld() == null) {
            return false;
        }
        if (!location.getWorld().getUID().equals(center.getWorld().getUID())) {
            return false;
        }
        final double dx = location.getX() - center.getX();
        final double dz = location.getZ() - center.getZ();
        return dx * dx + dz * dz <= this.protectedRadius * (double)this.protectedRadius;
    }
    
    public boolean isProtectedBlock(final Block block) {
        return block != null && this.isInProtectedRadius(block.getLocation());
    }
    
    public BossBar getBossBar() {
        return this.bossBar;
    }
    
    public long getSpawnTime() {
        return this.spawnTime;
    }
    
    public long getBossDuration() {
        return this.bossDuration;
    }
    
    public void setBossDuration(final long bossDuration) {
        this.bossDuration = bossDuration;
    }
    
    public boolean isShulkerUnlocked() {
        return this.shulkerUnlocked;
    }
    
    public void setShulkerUnlocked(final boolean shulkerUnlocked) {
        this.shulkerUnlocked = shulkerUnlocked;
    }
    
    public boolean isShulkerOpened() {
        return this.shulkerOpened;
    }
    
    public void setShulkerOpened(final boolean shulkerOpened) {
        this.shulkerOpened = shulkerOpened;
    }
    
    public Map<UUID, Boolean> getPlayerHasLooted() {
        return this.playerHasLooted;
    }
    
    public CuboidRegion getSavedRegion() {
        return this.savedRegion;
    }
    
    public void setSavedRegion(final CuboidRegion savedRegion) {
        this.savedRegion = savedRegion;
    }
    
    public CuboidRegion getParticleRegion() {
        return this.particleRegion;
    }
    
    public void setParticleRegion(final CuboidRegion particleRegion) {
        this.particleRegion = particleRegion;
    }
    
    public boolean isSchematicPlaced() {
        return this.schematicPlaced;
    }
    
    public void setSchematicPlaced(final boolean schematicPlaced) {
        this.schematicPlaced = schematicPlaced;
    }
    
    public BlockVector3 getSchematicOrigin() {
        return this.schematicOrigin;
    }
    
    public void setSchematicOrigin(final BlockVector3 schematicOrigin) {
        this.schematicOrigin = schematicOrigin;
    }
    
    public BlockVector3 getSchematicCenterWorld() {
        return this.schematicCenterWorld;
    }
    
    public void setSchematicCenterWorld(final BlockVector3 schematicCenterWorld) {
        this.schematicCenterWorld = schematicCenterWorld;
    }
    
    public String getWorldGuardRegionId() {
        return this.worldGuardRegionId;
    }
    
    public void setWorldGuardRegionId(final String worldGuardRegionId) {
        this.worldGuardRegionId = worldGuardRegionId;
    }
    
    public Map<String, BlockState> getOriginalBlocks() {
        return this.originalBlocks;
    }
    
    public boolean hasOriginalBlock(final String key) {
        return this.originalBlocks.containsKey(key);
    }
    
    public void saveOriginalBlock(final String key, final BlockState state) {
        this.originalBlocks.put(key, state);
    }
    
    public void clearOriginalBlocks() {
        this.originalBlocks.clear();
    }
    
    public List<BlockVector3> getPlacedBlockPositions() {
        return this.placedBlockPositions;
    }
    
    public void clearPlacedBlockPositions() {
        this.placedBlockPositions.clear();
    }
    
    public int getCurrentStageIndex() {
        return this.currentStageIndex;
    }
    
    public void setCurrentStageIndex(final int currentStageIndex) {
        this.currentStageIndex = currentStageIndex;
    }
    
    public int getCurrentStageSecondsLeft() {
        return this.currentStageSecondsLeft;
    }
    
    public void setCurrentStageSecondsLeft(final int currentStageSecondsLeft) {
        this.currentStageSecondsLeft = currentStageSecondsLeft;
    }
    
    public int getBossBarTaskId() {
        return this.bossBarTaskId;
    }
    
    public void setBossBarTaskId(final int bossBarTaskId) {
        this.bossBarTaskId = bossBarTaskId;
    }
    
    public int getCleanupTaskId() {
        return this.cleanupTaskId;
    }
    
    public void setCleanupTaskId(final int cleanupTaskId) {
        this.cleanupTaskId = cleanupTaskId;
    }
    
    public int getLootPopulateTaskId() {
        return this.lootPopulateTaskId;
    }
    
    public void setLootPopulateTaskId(final int lootPopulateTaskId) {
        this.lootPopulateTaskId = lootPopulateTaskId;
    }
    
    public boolean isLootPopulating() {
        return this.lootPopulating;
    }
    
    public void setLootPopulating(final boolean lootPopulating) {
        this.lootPopulating = lootPopulating;
    }
    
    public boolean isLootGenerated() {
        return this.lootGenerated;
    }
    
    public void setLootGenerated(final boolean lootGenerated) {
        this.lootGenerated = lootGenerated;
    }
    
    public Inventory getLootInventory() {
        return this.lootInventory;
    }
    
    public void setLootInventory(final Inventory lootInventory) {
        this.lootInventory = lootInventory;
    }
    
    public List<UUID> getHologramIds() {
        return this.hologramIds;
    }
    
    public void setHologramIds(final List<UUID> hologramIds) {
        this.hologramIds = ((hologramIds == null) ? new ArrayList<UUID>() : hologramIds);
    }
    
    public int getHologramTaskId() {
        return this.hologramTaskId;
    }
    
    public void setHologramTaskId(final int hologramTaskId) {
        this.hologramTaskId = hologramTaskId;
    }
    
    public int getParticleTaskId() {
        return this.particleTaskId;
    }
    
    public void setParticleTaskId(final int particleTaskId) {
        this.particleTaskId = particleTaskId;
    }
}
