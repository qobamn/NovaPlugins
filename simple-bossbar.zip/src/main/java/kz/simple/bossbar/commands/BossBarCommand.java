package kz.simple.bossbar.commands;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kz.simple.bossbar.SimpleBossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BossBarCommand implements CommandExecutor, TabCompleter {

    private final SimpleBossBar plugin;
    private static final MiniMessage MM = MiniMessage.miniMessage();

    public BossBarCommand(SimpleBossBar plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("simplebossbar.admin")) {
            sender.sendMessage(MM.deserialize("<red>Сізде бұл команданы орындауға рұқсат жоқ!"));
            return true;
        }

        if (args.length == 0) {
            this.sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                // BossBar қайта жүктеу
                plugin.getBossBarManager().reload();

                // ItemJoin конфигурациясын да қайта жүктеу
                plugin.getItemJoinManager().loadConfig();

                // Онлайн ойыншыларға item-ді жаңа конфигмен қайта беру
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    plugin.getItemJoinManager().giveAnarchyItem(player);
                }

                sender.sendMessage(MM.deserialize("<green>SimpleBossBar қайта жүктелді! Item-дер жаңартылды."));
            }
            case "help" -> this.sendHelp(sender);
            default -> sender.sendMessage(MM.deserialize("<red>Белгісіз команда. <gray>/bossbar help"));
        }

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(MM.deserialize("<dark_gray><strikethrough>                                        "));
        sender.sendMessage(MM.deserialize("<gray>/bossbar reload <dark_gray>- конфигурацияны қайта жүктеу"));
        sender.sendMessage(MM.deserialize("<gray>/bossbar help <dark_gray>- көмек"));
        sender.sendMessage(MM.deserialize("<dark_gray><strikethrough>                                        "));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("simplebossbar.admin")) return new ArrayList<>();

        if (args.length == 1) {
            List<String> completions = Arrays.asList("reload", "help");
            List<String> result = new ArrayList<>();
            for (String s : completions) {
                if (s.startsWith(args[0].toLowerCase())) result.add(s);
            }
            return result;
        }

        return new ArrayList<>();
    }
}
