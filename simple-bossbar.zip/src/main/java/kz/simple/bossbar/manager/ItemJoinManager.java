package kz.simple.bossbar.manager;

import kz.simple.bossbar.SimpleBossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ItemJoinManager {

    private final SimpleBossBar plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    // PersistentDataContainer key — бұл item-ті дәл анықтайды
    private final NamespacedKey ANARCHY_KEY;

    // items.yml-ден оқылатын мәндер
    private int slot;
    private Material material;
    private String displayName;
    private List<String> lore;
    private String command;

    public ItemJoinManager(SimpleBossBar plugin) {
        this.plugin = plugin;
        this.ANARCHY_KEY = new NamespacedKey(plugin, "anarchy_menu_item");
        this.loadConfig();
    }

    /**
     * items.yml файлынан конфигурацияны оқиды.
     */
    public void loadConfig() {
        File itemsFile = new File(plugin.getDataFolder(), "items.yml");
        if (!itemsFile.exists()) {
            plugin.saveResource("items.yml", false);
        }

        FileConfiguration config = YamlConfiguration.loadConfiguration(itemsFile);

        // items.yml-ден мәндерді оқу
        String materialStr = config.getString("anarchy-item.material", "TNT").toUpperCase();
        try {
            this.material = Material.valueOf(materialStr);
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("items.yml: қате material '" + materialStr + "', TNT қолданылады.");
            this.material = Material.TNT;
        }

        this.slot        = config.getInt("anarchy-item.slot", 4);
        this.displayName = config.getString("anarchy-item.display-name",
                "<gradient:#8B48EE:#FFFFFF>Анархия</gradient>");
        this.lore        = config.getStringList("anarchy-item.lore");
        this.command     = config.getString("anarchy-item.command", "dm open anarchy_menu");

        plugin.getLogger().info("ItemJoin конфигурациясы жүктелді. Slot=" + slot
                + ", Material=" + material + ", Command=" + command);
    }

    /**
     * Ойыншыға анархия меню item береді.
     */
    public void giveAnarchyItem(Player player) {
        ItemStack item = createAnarchyItem();
        player.getInventory().setItem(slot, item);
    }

    /**
     * items.yml-дегі мәндер бойынша item жасайды.
     * PersistentDataContainer арқылы таңба қояды — дәл анықтау үшін.
     */
    public ItemStack createAnarchyItem() {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // DisplayName
        Component displayNameComp = miniMessage.deserialize(displayName);
        meta.displayName(displayNameComp);

        // Lore
        if (!lore.isEmpty()) {
            List<Component> loreComponents = new ArrayList<>();
            for (String line : lore) {
                loreComponents.add(miniMessage.deserialize(line));
            }
            meta.lore(loreComponents);
        }

        // PersistentDataContainer — анық анықтау үшін таңба
        meta.getPersistentDataContainer().set(ANARCHY_KEY, PersistentDataType.BYTE, (byte) 1);

        // Item-тің кейбір мүмкіндіктерін жасырамыз
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * PersistentDataContainer арқылы дәл тексереді.
     * Басқа плагиндердің TNT-тері жалған оқталмайды.
     */
    public boolean isAnarchyItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(ANARCHY_KEY, PersistentDataType.BYTE);
    }

    public String getCommand() {
        return command;
    }

    public int getSlot() {
        return slot;
    }
}
