package kz.simple.bossbar;

import kz.simple.bossbar.commands.BossBarCommand;
import kz.simple.bossbar.listeners.ItemJoinListener;
import kz.simple.bossbar.listeners.PlayerListener;
import kz.simple.bossbar.manager.BossBarManager;
import kz.simple.bossbar.manager.ItemJoinManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SimpleBossBar extends JavaPlugin {

    private static SimpleBossBar instance;
    private BossBarManager bossBarManager;
    private ItemJoinManager itemJoinManager;

    @Override
    public void onEnable() {
        instance = this;

        // Config файлдарын бірінші рет сақтаймыз (бар болса қайта жазбаймыз)
        this.saveResource("bossbar.yml", false);
        this.saveResource("items.yml", false);

        // Manager-лер
        this.bossBarManager = new BossBarManager(this);
        this.bossBarManager.load();

        this.itemJoinManager = new ItemJoinManager(this);

        // Команда тіркеу
        BossBarCommand commandExecutor = new BossBarCommand(this);
        org.bukkit.command.PluginCommand cmd = this.getCommand("bossbar");
        if (cmd != null) {
            cmd.setExecutor(commandExecutor);
            cmd.setTabCompleter(commandExecutor);
        } else {
            this.getLogger().severe("'bossbar' командасы табылмады! plugin.yml тексеріңіз.");
        }

        // Listener-лер
        this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        this.getServer().getPluginManager().registerEvents(new ItemJoinListener(this), this);

        this.getLogger().info("SimpleBossBar v1.0.2 қосылды!");
    }

    @Override
    public void onDisable() {
        if (this.bossBarManager != null) {
            this.bossBarManager.removeAll();
        }
        // Scheduler задачалары plugin disable болған кезде Bukkit өзі тазалайды.
        this.getLogger().info("SimpleBossBar өшірілді.");
    }

    public static SimpleBossBar getInstance() {
        return instance;
    }

    public BossBarManager getBossBarManager() {
        return this.bossBarManager;
    }

    public ItemJoinManager getItemJoinManager() {
        return this.itemJoinManager;
    }
}
