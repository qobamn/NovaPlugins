package kz.simple.bossbar.listeners;

import kz.simple.bossbar.SimpleBossBar;
import kz.simple.bossbar.manager.ItemJoinManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class ItemJoinListener implements Listener {

    private final SimpleBossBar plugin;
    private final ItemJoinManager itemJoinManager;

    public ItemJoinListener(SimpleBossBar plugin) {
        this.plugin = plugin;
        this.itemJoinManager = plugin.getItemJoinManager();
    }

    // ─────────────────────────────────────────
    //  1. Ойыншы кірген кезде item беру
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // 1 tick кейін береміз — inventory толық жүктелсін.
        // isOnline() тексерісі: lag spike кезінде ойыншы шыға кетуі мүмкін.
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                itemJoinManager.giveAnarchyItem(player);
            }
        }, 1L);
    }

    // ─────────────────────────────────────────
    //  2. ПКМ / ЛКМ — меню ашу
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        // Тек MAIN_HAND (қос trigger болдырмаймыз)
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        boolean isClick = action == Action.RIGHT_CLICK_AIR
                || action == Action.RIGHT_CLICK_BLOCK
                || action == Action.LEFT_CLICK_AIR
                || action == Action.LEFT_CLICK_BLOCK;
        if (!isClick) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (itemJoinManager.isAnarchyItem(item)) {
            event.setCancelled(true);
            // items.yml-дегі command орындалады ("dm open anarchy_menu")
            // performCommand / алдындағы slash-сыз жұмыс жасайды
            player.performCommand(itemJoinManager.getCommand());
        }
    }

    // ─────────────────────────────────────────
    //  3. Item тастауға тыйым
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onItemDrop(PlayerDropItemEvent event) {
        if (itemJoinManager.isAnarchyItem(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
        }
    }

    // ─────────────────────────────────────────
    //  4. Инвентарьда жылжытуға тыйым
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;

        ItemStack current = event.getCurrentItem();
        ItemStack cursor  = event.getCursor();

        // PersistentDataContainer арқылы тексерілетіндіктен DeluxeMenus-тің
        // өз item-дері жалған оқталмайды — тек біздің NBT-таңбалы item блокталады.
        if (itemJoinManager.isAnarchyItem(current) || itemJoinManager.isAnarchyItem(cursor)) {
            event.setCancelled(true);
        }
    }

    // ─────────────────────────────────────────
    //  5. Drag арқылы жылжытуға тыйым
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (itemJoinManager.isAnarchyItem(event.getOldCursor())) {
            event.setCancelled(true);
        }
    }

    // ─────────────────────────────────────────
    //  6. Жерге қоюға тыйым (BlockPlace)
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (itemJoinManager.isAnarchyItem(event.getItemInHand())) {
            event.setCancelled(true);
        }
    }

    // ─────────────────────────────────────────
    //  7. Блок бұзуға тыйым — BlockBreakEvent
    //     LEFT_CLICK_BLOCK PlayerInteractEvent-те
    //     кейде серверде өтіп кетуі мүмкін, сондықтан
    //     BlockBreakEvent қосымша қауіпсіздік ретінде тіркелген.
    // ─────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        if (itemJoinManager.isAnarchyItem(event.getPlayer().getInventory().getItemInMainHand())) {
            event.setCancelled(true);
        }
    }
}
