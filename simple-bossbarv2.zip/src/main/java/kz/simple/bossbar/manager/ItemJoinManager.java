package kz.simple.bossbar.manager;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import kz.simple.bossbar.SimpleBossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ItemJoinManager {

    private final SimpleBossBar plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final NamespacedKey ANARCHY_KEY;

    // items.yml-ден оқылатын мәндер
    private int slot;
    private String materialRaw;  // "TNT", "basehead-<base64>", "PLAYER_HEAD" т.б.
    private String displayName;
    private List<String> lore;
    private String command;

    public ItemJoinManager(SimpleBossBar plugin) {
        this.plugin = plugin;
        this.ANARCHY_KEY = new NamespacedKey(plugin, "anarchy_menu_item");
        this.loadConfig();
    }

    public void loadConfig() {
        File itemsFile = new File(plugin.getDataFolder(), "items.yml");
        if (!itemsFile.exists()) {
            plugin.saveResource("items.yml", false);
        }

        FileConfiguration config = YamlConfiguration.loadConfiguration(itemsFile);

        this.slot        = config.getInt("anarchy-item.slot", 4);
        this.materialRaw = config.getString("anarchy-item.material",
                "basehead-eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMzY0YmJmMWRlZDgxY2IxNDY1ZTdkMGZhM2E3YWQzZjViNDJlMjgxMWM5NTRhZTY0MGIzZWM1ZTI1OThkNzRlMSJ9fX0=");
        this.displayName = config.getString("anarchy-item.display-name",
                "<gradient:#8B48EE:#FFFFFF>Анархия</gradient>");
        this.lore        = config.getStringList("anarchy-item.lore");
        this.command     = config.getString("anarchy-item.command", "dm open anarchy_menu");

        plugin.getLogger().info("ItemJoin жүктелді. Slot=" + slot
                + ", Material=" + materialRaw + ", Command=" + command);
    }

    public void giveAnarchyItem(Player player) {
        player.getInventory().setItem(slot, createAnarchyItem());
    }

    /**
     * Item жасайды. materialRaw форматтары:
     *   "TNT"                 → кәдімгі TNT
     *   "PLAYER_HEAD"         → текстурасыз бас (ванилла)
     *   "basehead-<base64>"   → custom skull, Base64 texture бар
     */
    public ItemStack createAnarchyItem() {
        ItemStack item;
        boolean isSkull = false;
        String skullTexture = null;

        if (materialRaw.toLowerCase().startsWith("basehead-")) {
            // "basehead-<base64>" форматы
            skullTexture = materialRaw.substring("basehead-".length()).trim();
            item = new ItemStack(Material.PLAYER_HEAD);
            isSkull = true;
        } else {
            Material mat;
            try {
                mat = Material.valueOf(materialRaw.toUpperCase());
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning(
                        "items.yml: қате material '" + materialRaw + "', PLAYER_HEAD қолданылады.");
                mat = Material.PLAYER_HEAD;
                isSkull = true;
            }
            // Material PLAYER_HEAD болса — skull логикасына кіреміз
            if (mat == Material.PLAYER_HEAD || mat == Material.PLAYER_WALL_HEAD) {
                isSkull = true;
            }
            item = new ItemStack(mat);
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        // SkullMeta — Base64 texture орнату
        if (isSkull && skullTexture != null && !skullTexture.isEmpty()
                && meta instanceof SkullMeta skullMeta) {
            applySkullTexture(skullMeta, skullTexture);
        }

        // DisplayName
        meta.displayName(miniMessage.deserialize(displayName));

        // Lore
        if (!lore.isEmpty()) {
            List<Component> loreComponents = new ArrayList<>();
            for (String line : lore) {
                loreComponents.add(miniMessage.deserialize(line));
            }
            meta.lore(loreComponents);
        }

        // PersistentDataContainer — дәл анықтау үшін NBT тег
        meta.getPersistentDataContainer().set(ANARCHY_KEY, PersistentDataType.BYTE, (byte) 1);

        // Артық мүмкіндіктерді жасырамыз
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Paper API арқылы SkullMeta-ға Base64 текстурасын орнатады.
     * PlayerProfile + ProfileProperty("textures", base64) — Paper 1.18+ қолдайды.
     */
    private void applySkullTexture(SkullMeta skullMeta, String base64) {
        try {
            PlayerProfile profile = Bukkit.createProfile(UUID.randomUUID(), "CustomSkull");
            profile.setProperty(new ProfileProperty("textures", base64));
            skullMeta.setPlayerProfile(profile);
        } catch (Exception e) {
            plugin.getLogger().warning("Skull texture орнату сәтсіз: " + e.getMessage());
        }
    }

    /**
     * NBT тег арқылы дәл анықтайды.
     */
    public boolean isAnarchyItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(ANARCHY_KEY, PersistentDataType.BYTE);
    }

    public String getCommand() { return command; }
    public int getSlot()       { return slot; }
}
