package kz.simple.bossbar.manager;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import kz.simple.bossbar.SimpleBossBar;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.bossbar.BossBar.Color;
import net.kyori.adventure.bossbar.BossBar.Overlay;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BossBarManager {

    private final SimpleBossBar plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private final ConcurrentHashMap<UUID, BossBar> playerBossBars = new ConcurrentHashMap<>();

    private FileConfiguration bossBarConfig;
    private File bossBarFile;

    private boolean enabled;
    private float progress;
    private BossBar.Overlay overlay;
    private int animationInterval;
    private List<FrameEntry> frames;
    private BukkitTask animationTask;

    // Ping-pong анимация үшін
    private int animationIndex = 0;   // қазіргі frame индексі
    private boolean goingForward = true; // бағыт: алға немесе артқа

    public BossBarManager(SimpleBossBar plugin) {
        this.plugin = plugin;
    }

    public void load() {
        this.loadConfig();
        if (this.enabled && this.frames != null && !this.frames.isEmpty()) {
            this.startAnimation();
        }
    }

    private void loadConfig() {
        this.bossBarFile = new File(this.plugin.getDataFolder(), "bossbar.yml");
        if (!this.bossBarFile.exists()) {
            this.plugin.saveResource("bossbar.yml", false);
        }

        this.bossBarConfig = YamlConfiguration.loadConfiguration(this.bossBarFile);
        this.enabled = this.bossBarConfig.getBoolean("enabled", true);
        this.progress = (float) Math.max(0.0, Math.min(1.0,
                this.bossBarConfig.getDouble("progress", 1.0)));

        String styleStr = this.bossBarConfig.getString("style", "PROGRESS").toUpperCase();
        this.overlay = this.parseOverlay(styleStr);

        this.animationInterval = this.bossBarConfig.getInt("animation.interval", 60);
        this.frames = new ArrayList<>();

        ConfigurationSection framesSection =
                this.bossBarConfig.getConfigurationSection("animation.frames");
        if (framesSection != null) {
            List<String> sortedKeys = new ArrayList<>(framesSection.getKeys(false));
            sortedKeys.sort(Comparator.comparingInt(k -> {
                try { return Integer.parseInt(k); }
                catch (NumberFormatException e) { return Integer.MAX_VALUE; }
            }));

            for (String key : sortedKeys) {
                ConfigurationSection section = framesSection.getConfigurationSection(key);
                if (section != null) {
                    String title = section.getString("title", "SimpleBossBar");
                    String colorStr = section.getString("color", "BLUE").toUpperCase();
                    this.frames.add(new FrameEntry(title, this.parseColor(colorStr)));
                }
            }
        }

        this.plugin.getLogger().info(
                "BossBar конфигурациясы жүктелді. Frames: " + this.frames.size());
    }

    public void reload() {
        this.stopAnimation();
        this.removeAll();
        this.loadConfig();

        for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            this.showBossBar(player);
        }

        if (this.enabled && this.frames != null && !this.frames.isEmpty()) {
            this.startAnimation();
        }
    }

    public void showBossBar(Player player) {
        if (!this.enabled) return;
        this.removeBossBar(player);

        // Анимацияның қазіргі позициясындағы frame-ді алу
        FrameEntry current = this.frames.isEmpty()
                ? new FrameEntry("BossBar", Color.BLUE)
                : this.frames.get(Math.min(this.animationIndex, this.frames.size() - 1));

        Component titleComponent = this.miniMessage.deserialize(current.title);
        BossBar bossBar = BossBar.bossBar(
                titleComponent, this.progress, current.color, this.overlay);

        this.playerBossBars.put(player.getUniqueId(), bossBar);
        player.showBossBar(bossBar);
    }

    public void removeBossBar(Player player) {
        BossBar existing = this.playerBossBars.remove(player.getUniqueId());
        if (existing != null) {
            player.hideBossBar(existing);
        }
    }

    public void removeAll() {
        for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            this.removeBossBar(player);
        }
        this.playerBossBars.clear();
    }

    /**
     * Ping-pong (bounce) анимация:
     *   Frame саны 1 болса  → тек сол frame көрсетіледі
     *   Frame саны 2 болса  → 0 → 1 → 0 → 1 ...
     *   Frame саны 3 болса  → 0 → 1 → 2 → 1 → 0 → 1 → 2 ...
     *
     * Яғни бірінші және соңғы frame-дер бір рет, ортадағылар екі рет ойнайды.
     */
    private void startAnimation() {
        this.animationIndex = 0;
        this.goingForward = true;

        this.animationTask = new BukkitRunnable() {
            @Override
            public void run() {
                int size = BossBarManager.this.frames.size();
                if (size == 0) return;

                // Қазіргі frame-ді барлық ойыншыларға жіберу
                FrameEntry frame = BossBarManager.this.frames.get(BossBarManager.this.animationIndex);
                Component title = BossBarManager.this.miniMessage.deserialize(frame.title);

                for (BossBar bar : BossBarManager.this.playerBossBars.values()) {
                    bar.name(title);
                    bar.color(frame.color);
                }

                // Келесі индексті есептеу (ping-pong логикасы)
                if (size == 1) {
                    // Бір frame ғана — қозғалыс жоқ
                    return;
                }

                if (BossBarManager.this.goingForward) {
                    BossBarManager.this.animationIndex++;
                    if (BossBarManager.this.animationIndex >= size - 1) {
                        // Соңғы frame-ге жеттік — артқа бұрыламыз
                        BossBarManager.this.animationIndex = size - 1;
                        BossBarManager.this.goingForward = false;
                    }
                } else {
                    BossBarManager.this.animationIndex--;
                    if (BossBarManager.this.animationIndex <= 0) {
                        // Бірінші frame-ге жеттік — алға бұрыламыз
                        BossBarManager.this.animationIndex = 0;
                        BossBarManager.this.goingForward = true;
                    }
                }
            }
        }.runTaskTimer(this.plugin, 0L, (long) this.animationInterval);
    }

    private void stopAnimation() {
        if (this.animationTask != null && !this.animationTask.isCancelled()) {
            this.animationTask.cancel();
            this.animationTask = null;
        }
        // Бағытты қайтарамыз
        this.animationIndex = 0;
        this.goingForward = true;
    }

    private BossBar.Color parseColor(String colorStr) {
        return switch (colorStr) {
            case "PINK"   -> Color.PINK;
            case "RED"    -> Color.RED;
            case "GREEN"  -> Color.GREEN;
            case "YELLOW" -> Color.YELLOW;
            case "PURPLE" -> Color.PURPLE;
            case "WHITE"  -> Color.WHITE;
            case "BLUE"   -> Color.BLUE;
            default       -> Color.BLUE;
        };
    }

    private BossBar.Overlay parseOverlay(String styleStr) {
        return switch (styleStr) {
            case "NOTCHED_6"  -> Overlay.NOTCHED_6;
            case "NOTCHED_10" -> Overlay.NOTCHED_10;
            case "NOTCHED_12" -> Overlay.NOTCHED_12;
            case "NOTCHED_20" -> Overlay.NOTCHED_20;
            default           -> Overlay.PROGRESS;
        };
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    private static class FrameEntry {
        final String title;
        final BossBar.Color color;

        FrameEntry(String title, BossBar.Color color) {
            this.title = title;
            this.color = color;
        }
    }
}
